# Revision competitiva de partidas reales v7
Informe elaborado el 12/10/2026. Partidas del 11/10/2026. Solo analisis: no se modificaron codigo, estrategia, pesos ni archivos del proyecto.

## Alcance y trazabilidad

Se congelo una tanda de **86 partidas completas**, version declarada **2.16**, con archivos terminados entre 21:26:00 y 21:49:07 inclusive (hora local; corte por ultima modificacion del log). Sus identificadores pertenecen a los grupos c5d3/c5d4/c5d5. El manifiesto al final permite repetir el corte sin incorporar partidas nuevas.

La pregunta previa mencionaba 87 partidas y 48 derrotas: incluia una partida posterior. Se excluyeron expresamente game_56248aa4-c5d9-11f1-96f5-a2aacf8fcf85.log (22:10:12) y game_e0d34e10-c5d9-11f1-96f5-a2aacf8fcf85.log (22:19:23). No se usaron logs de reglas antiguas para conclusiones estrategicas.

Los logs identifican version, pero no commit ni hash de pesos del proceso. La version historica exacta no puede certificarse criptograficamente. El archivo activo en disco no se modifico; su SHA256 observado es FE93C636286B307218006EA6398CC16E9AB4CF609EF40A827567D79D228092A8.

Se revisaron 15.378 decisiones propias. Una alternativa con mayor valor interno no prueba que ganara una partida: no se jugaron contrafactuales, benchmarks ni optimizaciones.

## Resultado global

| Metrica | Resultado |
|---|---:|
| Partidas | 86 |
| Victorias | 39 |
| Derrotas | 47 |
| Empates | 0 |
| Porcentaje de victorias | 45,35% |
| Diferencia media de score propia menos rival | -12.356,43 |
| Mediana de diferencia | -5.279,5 |
| Como A | 19 victorias / 25 derrotas |
| Como B | 20 victorias / 22 derrotas |
| Finales por 400 movimientos | 21 victorias / 45 derrotas |
| Finales por eliminacion | 8 victorias / 2 derrotas |
| Finales anticipados de causa no identificable | 10 victorias |

Las diez victorias anticipadas tienen remaining_moves=-1, rival con score 0 y cuerpo mayor que 3, sin campo oficial de causa. Podrian ser desconexiones o abandonos, pero no se puede afirmarlo. No son prueba de superioridad estrategica ni eliminaciones por score confirmadas. En finales de 400 movimientos el record es 21-45.

Hay una diferencia moderada A/B (43,18% contra 47,62%), pero rivales y escenarios no estan pareados: no permite atribuir causalmente la diferencia a empezar.

## Tres prioridades, en orden

### 1. Objetivos X fuera del horizonte real

**Clasificacion:** inconsistencia del horizonte de planificacion y problema estrategico repetido; no es un error de las transiciones oficiales del estado.

Se detectaron **47 planes X inalcanzables en 20 partidas**; en 38 decisiones el movimiento final quedo atribuido a food_plan. En 11 casos incluso se proyectaba ingreso positivo aunque no quedaran turnos propios para llegar.

[simulate_path_to_food](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/snake_bot/food_planner.py:93>) simula pasos propios consecutivos y descuenta un movimiento global por paso. Para d pasos propios desde nuestro turno, la llegada real cuesta 2d-1 movimientos globales. El estado artificial usa R-d en vez de R-(2d-1). La proyeccion economica puede asignar turnos adicionales, y la comparacion marginal de X enfrenta presupuestos temporales distintos. Ademas, X conserva valor de carrera/denegacion aunque el ingreso proyectado sea cero, sin filtro obligatorio de alcanzabilidad temporal.

Referencias: [estado de llegada](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/snake_bot/food_planner.py:869>), [ingreso y marginal X](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/snake_bot/food_planner.py:899>), [valor del objetivo](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/snake_bot/food_planner.py:904>), [seleccion](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/snake_bot/food_planner.py:1107>), [commit del objetivo](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/snake_bot/food_planner.py:1237>).

**Caso fuerte: [5580bbd6](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_5580bbd6-c5d4-11f1-96f5-a2aacf8fcf85.log:576>).** Turno propio 192, remaining_moves=18: quedan 9 turnos propios. Scores 19.720-58.166, multiplicadores 6-11, hambre 36. Se elige down hacia X (7,15), a 14 pasos, con ingreso marginal cero. Habia X (8,3), a 5 pasos, rival a 10, ruta SAFE y primer paso left. Su valor registrado era 65.827 frente a 62.662 del lejano. La ruta (9,7), (9,6), (9,5), (9,4), (8,4), (8,3) es compatible con los tableros inmediatos; evita el 6 incorrecto en (9,3). El objetivo previo era el cercano, por lo que el cambio inicial no se explica simplemente por persistencia del objetivo lejano. Ambos X quedan al final; nuestro multiplicador sigue en 6 y solo sumamos 9 movimientos. Resultado 19.729-63.674. No se afirma que tomar el X cercano hubiera ganado.

**Confirmacion del ingreso artificial: [4837c1ee](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_4837c1ee-c5d5-11f1-96f5-a2aacf8fcf85.log:555>).** R=32, 16 turnos propios, X a 17 pasos; se proyectan 7.674 puntos con un estado artificial de llegada R=15. El objetivo no se alcanza y el multiplicador queda en 5. Up era el unico candidato SAFE: aqui el defecto del objetivo no demuestra que otro movimiento inmediato fuera mejor.

**Otra repeticion: [8d25279e](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_8d25279e-c5d3-11f1-96f5-a2aacf8fcf85.log:588>).** R=9, 5 turnos propios, X a 8 pasos frente a otro SAFE a 3. Ambos empiezan up: la correccion cambiaria el objetivo, no necesariamente la primera direccion.

**Caso con recuperacion: [474a1da4](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_474a1da4-c5d5-11f1-96f5-a2aacf8fcf85.log:552>).** R=34, X a 27 pasos con ingreso artificial 1.200 frente a X a 4 pasos, ingreso 5.246. El movimiento real fue tactical_override; dos lineas despues se selecciona el cercano y luego se consume. Es evidencia del horizonte, no de abandono persistente de un X alcanzable.

**Cambio minimo propuesto:** excluir objetivos X cuya distancia supere los turnos propios restantes y corregir el presupuesto de llegada/ingreso. Preservar pesos, evaluacion restante y limites de busqueda. Es lo primero que atacaria: tiene un criterio objetivo, casos repetidos y regresiones faciles de reproducir.

### 2. Saturacion que borra diferencias de busqueda profunda

**Clasificacion:** integracion de busqueda/normalizacion, con perdida de informacion comprobada; mejora competitiva pendiente de validar.

En **2.589 de 7.357 decisiones elegibles** (profundidad >=4, al menos dos candidatos no forced_loss y valores distintos) todos los valores terminan iguales por clipping absoluto a +/-200.000. Ocurre en **76 partidas**: 773 decisiones ganando y 1.816 perdiendo. El ajuste profundo queda cero aunque la busqueda distinga alternativas.

[normalizacion](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/snake_bot/move_search.py:575>) recorta cada valor antes de centrarlo. [evaluacion profunda](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/snake_bot/search_engine.py:439>) incluye la diferencia de score multiplicada por 22: un desplazamiento comun grande satura candidatos distintos.

Caso [8d25279e](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_8d25279e-c5d3-11f1-96f5-a2aacf8fcf85.log:498>): turno 166, R=69, B, up por survival_control frente a down, ambos SAFE. Valores profundos -431.010 y -322.732; ambos se convierten en -200.000 y ajuste cero. La evaluacion somera tambien favorecia down (39.145 frente a 33.723), pero la preferencia de movilidad cercana puede reordenar. Hay discrepancia medible; no se demostro victoria alternativa.

Referencias adicionales: [prefer_safer_close_move](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/snake_bot/move_search.py:609>) permite promover movilidad dentro de un margen de 30.000; [deep_sort_key](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/snake_bot/move_search.py:633>) prioriza seguridad y ausencia de forced_loss antes del escalar.

**Cambio minimo propuesto:** estudiar centrar valores crudos antes de recortar diferencias, conservando factor 35%, tope 25.000, filtro de profundidad y seguridad. Deben probarse explicitamente conjuntos con valores terminales +/-500 millones (eliminacion) y +/-300 millones (fin): centrar primero sin tratar esos casos puede introducir otra distorsion. No tocar alpha-beta, profundidad, tiempos ni pesos.

### 3. Concurrencia extrema y presupuestos reducidos

**Clasificacion:** carga operativa y presupuesto de busqueda. No se demostro que cause una derrota particular.

Hubo hasta **59 partidas simultaneas**. De 15.378 decisiones, 13.915 usaron 10 ms (90,49%) y 14.814 usaron como maximo 18 ms (96,33%). Solo 15 usaron 45 ms; 26 carecen de este diagnostico.

[presupuesto por partidas activas](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/snake_bot/snake_brain.py:403>) asigna 45/30/18/10 ms para menos de 4, 4-7, 8-15 y >=16 partidas. [modo rapido](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/snake_bot/move_search.py:505>) reduce trabajo adicional y omite Voronoi con <=18 ms. En 6.691 decisiones la profundidad fue inferior a 4: no se aplica el ajuste profundo mencionado antes.

No hay medicion fiable de tiempo total de decision ni de deadlines perdidos. Estadisticas de motor repetidas dentro de deep_moves se cuentan una sola vez. Voronoi cero en modo rapido es un marcador omitido, no territorio realmente cero.

**Validacion minima propuesta:** una tanda controlada con pocas partidas simultaneas, sin cambiar presupuestos ni rechazo/aceptacion de desafios. Comparar profundidad, estabilidad y resultados bajo carga parecida. No ajustar permanentemente tiempos basandose solo en estos logs.

## Choques y cola v7: validacion live separada

Esta tanda SI contiene choques y comida de cola reales. Ya no deben marcarse globalmente como pendientes de primera observacion live.

| Aspecto | Evidencia | Clasificacion |
|---|---|---|
| Transicion propia: cabeza, celdas/longitud, score, multiplicador | 15.378 acciones contrastadas con GameState/CompactState | Coincide en campos observables |
| Choques propios | 28: borde 15, cuerpo propio 10, pared 2, rival 1 | Coincide |
| Inmovilidad y truncamiento a maximo 3 | 28/28 choques | Coincide |
| Primer choque propio con score positivo ->0 | 16/16 | Coincide |
| Primer choque propio con score cero o negativo | Sin caso propio observado | No pudo verificarse |
| Choques posteriores -500 | 12/12 | Coincide |
| Unicode y beneficiario de cola | Cola A/B en 30 partidas | Coincide en eventos observados |
| Consumo por beneficiario | 20/20: +100 por multiplicador, crecimiento de una celda | Coincide |
| Limpieza por originador | 76/76: +1, sin crecimiento, elimina la celda pisada | Coincide |
| Desprendimientos | 16; 13 totalmente visibles, 3 con una celda ya comida por rival | Compatible con alternancia observada |
| Score -2500 | Continua | Coincide |
| Score menor que -2500 | Dos derrotas propias terminan en -3000 | Coincide |
| Agotamiento de movimientos | 66 finales de 400 | Coincide |
| Finales anticipados sin causa | 10 victorias con R=-1 | No pudo determinarse la causa |

Los tres desprendimientos parcialmente visibles se explican por la accion intermedia del rival: 65d33bea (3,4), +800; d2eae89e (6,2), +1.200; dbf99c38 (11,7), +800, con crecimiento compatible.

Las derrotas por eliminacion [65d33bea](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_65d33bea-c5d3-11f1-96f5-a2aacf8fcf85.log:308>) y [d1cacc36](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_d1cacc36-c5d4-11f1-96f5-a2aacf8fcf85.log:446>) permiten observar continuidad en -2500 y final al siguiente choque en -3000.

Se observaron 95 transiciones rivales compatibles con choque, pero sin direccion/causa registrada; no son 95 choques confirmados. Se excluyeron 108 cambios inmoviles de otra naturaleza del conteo de esa inferencia.

La coincidencia no es una afirmacion de igualdad del estado global: entre tableros propios el rival actua y el servidor repone comida o contrae paredes. El orden corporal se reconstruye mediante seguimiento validado; el board no entrega un listado ordenado del cuerpo.

### Dos choques contra pared: regla correcta, eleccion discutible

[659ecc16](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_659ecc16-c5d3-11f1-96f5-a2aacf8fcf85.log:189>): A, turno 63, R=276. Down contra # en (4,4): cabeza inmovil (3,4), longitud 9->3, score 5.252->0. Right comia 8 incorrecto, predecia 4.752 y longitud 10. Ambos ACCEPTABLE_RISK; la preferencia por movilidad podia favorecer el choque (tres respuestas propias frente a dos). Los valores profundos tambien se saturaban. La pared desaparece DESPUES por contraccion: no estaba ausente al mover. Esta partida se gano 45.915-40.020; no demuestra que el choque fuera estrategicamente malo.

[47b0ecc8](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_47b0ecc8-c5d5-11f1-96f5-a2aacf8fcf85.log:366>): B, turno 122, R=157. Left contra # (11,0): cabeza inmovil (11,1), longitud 19->3, score 19.103->0. Up comia 1 incorrecto y mantenia 18.603, pero se clasificaba SUICIDAL (region 1, sin salidas), frente a choque ACCEPTABLE_RISK (region 152). Es un intercambio entre score inmediato y espacio despues del truncamiento, no un bug por permitir # como accion v7. La alternativa evita ese choque inmediato, no garantiza una mejor partida.

## Otros aspectos solicitados

- **Comida correcta:** 1.588 consumos propios confirmados. Carreras/denegacion y secuencia participan del plan. No toda carrera perdida equivale a una ruta dominada: el rival mueve entre nuestras observaciones.
- **Comida incorrecta:** 22 consumos propios. Penalizacion y crecimiento coinciden con los motores; no se encontro una nueva divergencia de reglas. Puede ser preferible a perder todo el score positivo en un primer choque.
- **X:** 439 recogidos propios. El problema repetido comprobable es el horizonte, no una demostracion general de que todos los valores de denegacion son excesivos.
- **Orden de dos X:** [3f7633e4](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_3f7633e4-c5d3-11f1-96f5-a2aacf8fcf85.log:456>), R=98, scores 31.179-40.977, multiplicadores 6-8, hambre 0: right y down eran X adyacentes. Se elige right (valor profundo 48.826 frente a 35.068, ambos SAFE, profundidad 3), luego se va al norte. Rival cobra 8/9 (+6.400/+7.200); mas tarde toma el X de abajo. Resultado 45.973-69.567. Down primero permitia localmente conectar ambos X, pero no esta probado que evitara la secuencia rival o ganara. Evidencia insuficiente para una cuarta recomendacion.
- **Territorio:** regiones, salidas y movilidad permiten diagnosticar encierros locales. El modo rapido no produce una medicion Voronoi fiable para comparar territorio completo.
- **Encierros:** 14 primeros resets estaban forzados en el instante observado (sin movimientos seguros). Eso no demuestra que las decisiones anteriores fueran inevitables. De 16 primeros resets, 13 pertenecen a derrotas.
- **Ganando:** [05107bfa](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_05107bfa-c5d4-11f1-96f5-a2aacf8fcf85.log:576>), turno 192, R=17, score 51.063->0 frente a rival 48.315; los cuatro vecinos eran cuerpo propio. Resultado 4.507-50.719. [a8971630](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_a8971630-c5d4-11f1-96f5-a2aacf8fcf85.log:522>), turno 174, R=54, 50.794->0 cuando iba ganando; resultado 11.222-14.036. El fallback final no podia conservar la ventaja sin choque en esos estados; falta evaluar la ruta anterior.
- **Perdiendo:** la saturacion profunda aparece en 1.816 decisiones estando atras. No significa que todas deban cambiar ni que el valor profundo garantice recuperacion.
- **Overrides:** food_plan 12.916; tactical_override 1.000; survival_control 649; deep_control 423; fallback_rival_pressure 343; safe_direction_repair 26; advantage_control 17; otros 4. Un override puede priorizar una cualidad tactica distinta del escalar profundo. Umbrales 1.800 y, bajo condiciones, 450/700 merecen lectura contextual, no ajuste ciego.
- **Alternativas cercanas:** la preferencia de movilidad dentro de 30.000 puede invertir el orden de los escalares. Los ejemplos concretos se registran abajo; no se equipara diferencia de utilidad a diferencia de probabilidad de ganar.
- **Finales:** no se detecto que un choque ordinario termine indebidamente la partida ni que el rival cobre el antiguo +1.000.

## Como validaria el primer cambio contra la version actual

1. Congelar codigo y pesos de referencia; reproducir los estados concretos y su historial.
2. Tests de horizonte X: inalcanzable, llegada en ultimo turno propio, alcanzable, ambos lados y secuencia tras llegada. Comprobar que los casos factibles no cambien sin necesidad.
3. Comparar decisiones en los mismos snapshots. Para normalizacion, usar primero valores profundos registrados fijos y luego repetir motor completo por variabilidad temporal.
4. Hacer una comparacion pequena, 6-8 semillas espejadas, con mismos pesos, reglas y presupuestos, con una referencia de codigo realmente congelada.

**Limitacion actual:** [simulador](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/tools/bot_lab.py:303>) construye dos SnakeBrain del codigo actual y [benchmark](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/tools/benchmark_bot.py:235>) compara configuraciones de pesos, no revisiones distintas. Cambiar codigo y ejecutar self-play modifica ambos lados: no demuestra superioridad contra la version anterior. Para esa validacion haria falta un adaptador minimo de referencia congelada o procesos separados, no una reescritura del simulador.

Un smoke test existente de cuatro partidas puede comprobar regresiones, pero no superioridad competitiva. No se ejecuto ahora. Tampoco se ejecutaron tests: esta tarea no modifica codigo.

## Detalle de las 47 derrotas

Cada ficha selecciona un estado concreto de la derrota, no pretende explicar toda la partida por ese unico movimiento. Coordenadas en formato (fila,columna), desde cero. El turno es propio; remaining_moves es global antes de mover. El enlace lleva al decision_debug; el board esta en la linea anterior y el envio en la siguiente.

Clasificaciones de las fichas: 28 con perdida de diferencias por normalizacion (N), 12 encierros forzados en ese estado (F), 2 con objetivo X fuera del horizonte y alternativa alcanzable (H), 5 con evidencia insuficiente (I). Son categorias del estado seleccionado, no causas exclusivas de las 47 derrotas.

### 1. 0500270a: 40.478 - 73.771

- Rival ganador: santinovitale. Diferencia final propia: -33.293.
- Estado: turno propio 147, remaining_moves=107; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_0500270a-c5d4-11f1-96f5-a2aacf8fcf85.log:441>).
- Movimiento elegido: up. Alternativa: down.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search -447026 vs -445746; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 1.280, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 50. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 2. 05107bfa: 4.507 - 50.719

- Rival ganador: agustinnunez. Diferencia final propia: -46.212.
- Estado: turno propio 192, remaining_moves=17; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_05107bfa-c5d4-11f1-96f5-a2aacf8fcf85.log:576>).
- Movimiento elegido: down. Alternativa: sin salida sin choque.
- Motivo registrado: safe_direction_repair. Componentes: snake_brain.py (reparacion del movimiento), transicion v7 del estado.
- Evidencia: 51063 -> 0; legal=[].
- Clasificacion: 5. Choque dificil de evitar en este estado; 6. evidencia insuficiente sobre la ruta anterior.
- Limite de la conclusion: No habia movimiento seguro sin choque en este instante. No se culpa al fallback final ni se afirma que el encierro anterior fuera inevitable. La transicion de choque coincide con v7.

### 3. 2027a5c0: 23.979 - 89.367

- Rival ganador: Slowpoke. Diferencia final propia: -65.388.
- Estado: turno propio 177, remaining_moves=48; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_2027a5c0-c5d5-11f1-96f5-a2aacf8fcf85.log:531>).
- Movimiento elegido: right. Alternativa: down.
- Motivo registrado: tactical_override. Componentes: move_search.py (evaluacion/seguridad y candidatos), snake_brain.py (override/commit).
- Evidencia: search -1067904 vs -1012086; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 55.818, misma clase SAFE y no forced_loss; profundidad 5, partidas activas 15. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 4. 20a8f86e: 22.724 - 156.609

- Rival ganador: santinovitale. Diferencia final propia: -133.885.
- Estado: turno propio 116, remaining_moves=170; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_20a8f86e-c5d5-11f1-96f5-a2aacf8fcf85.log:348>).
- Movimiento elegido: up. Alternativa: right.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search -1394818 vs -1393948; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 870, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 30. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 5. 2cd0a804: 17.978 - 67.570

- Rival ganador: santinovitale. Diferencia final propia: -49.592.
- Estado: turno propio 186, remaining_moves=30; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_2cd0a804-c5d4-11f1-96f5-a2aacf8fcf85.log:558>).
- Movimiento elegido: up. Alternativa: down.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search -992134 vs -989894; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 2.240, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 42. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 6. 2d2994e6: 40.423 - 44.377

- Rival ganador: agustinnunez. Diferencia final propia: -3.954.
- Estado: turno propio 200, remaining_moves=1; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_2d2994e6-c5d4-11f1-96f5-a2aacf8fcf85.log:600>).
- Movimiento elegido: up. Alternativa: no demostrada.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: sin alternativa superior confirmada.
- Clasificacion: 6. Evidencia insuficiente.
- Limite de la conclusion: Se informa el ultimo estado elegido como referencia del final. No se demostro una alternativa mejor ni se atribuye la derrota a este movimiento.

### 7. 2d34f854: 41.774 - 88.369

- Rival ganador: Slowpoke. Diferencia final propia: -46.595.
- Estado: turno propio 143, remaining_moves=116; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_2d34f854-c5d4-11f1-96f5-a2aacf8fcf85.log:429>).
- Movimiento elegido: down. Alternativa: left.
- Motivo registrado: tactical_override. Componentes: move_search.py (evaluacion/seguridad y candidatos), snake_brain.py (override/commit).
- Evidencia: search -559434 vs -558244; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 1.190, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 56. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 8. 3f697122: 37.777 - 52.223

- Rival ganador: santinovitale. Diferencia final propia: -14.446.
- Estado: turno propio 200, remaining_moves=2; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_3f697122-c5d3-11f1-96f5-a2aacf8fcf85.log:600>).
- Movimiento elegido: up. Alternativa: no demostrada.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: sin alternativa superior confirmada.
- Clasificacion: 6. Evidencia insuficiente.
- Limite de la conclusion: Se informa el ultimo estado elegido como referencia del final. No se demostro una alternativa mejor ni se atribuye la derrota a este movimiento.

### 9. 3f6e66d2: 22.114 - 78.119

- Rival ganador: Porygon2. Diferencia final propia: -56.005.
- Estado: turno propio 123, remaining_moves=156; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_3f6e66d2-c5d3-11f1-96f5-a2aacf8fcf85.log:369>).
- Movimiento elegido: down. Alternativa: sin salida sin choque.
- Motivo registrado: safe_direction_repair. Componentes: snake_brain.py (reparacion del movimiento), transicion v7 del estado.
- Evidencia: 14401 -> 0; legal=[].
- Clasificacion: 5. Choque dificil de evitar en este estado; 6. evidencia insuficiente sobre la ruta anterior.
- Limite de la conclusion: No habia movimiento seguro sin choque en este instante. No se culpa al fallback final ni se afirma que el encierro anterior fuera inevitable. La transicion de choque coincide con v7.

### 10. 3f728c4e: 40.919 - 93.919

- Rival ganador: Slowpoke. Diferencia final propia: -53.000.
- Estado: turno propio 77, remaining_moves=247; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_3f728c4e-c5d3-11f1-96f5-a2aacf8fcf85.log:231>).
- Movimiento elegido: down. Alternativa: left.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search -280672 vs -208364; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 72.308, misma clase SAFE y no forced_loss; profundidad 5, partidas activas 6. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 11. 3f7633e4: 45.973 - 69.567

- Rival ganador: agustinnunez. Diferencia final propia: -23.594.
- Estado: turno propio 112, remaining_moves=178; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_3f7633e4-c5d3-11f1-96f5-a2aacf8fcf85.log:336>).
- Movimiento elegido: left. Alternativa: down.
- Motivo registrado: tactical_override. Componentes: move_search.py (evaluacion/seguridad y candidatos), snake_brain.py (override/commit).
- Evidencia: search -401530 vs -307682; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 93.848, misma clase SAFE y no forced_loss; profundidad 5, partidas activas 12. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 12. 474a1da4: 23.125 - 72.874

- Rival ganador: Slowpoke. Diferencia final propia: -49.749.
- Estado: turno propio 184, remaining_moves=34; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_474a1da4-c5d5-11f1-96f5-a2aacf8fcf85.log:552>).
- Movimiento elegido: up. Alternativa: left.
- Motivo registrado: tactical_override. Componentes: move_search.py (evaluacion/seguridad y candidatos), snake_brain.py (override/commit).
- Evidencia: search -1135942 vs -1116602; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 19.340, misma clase SAFE y no forced_loss; profundidad 5, partidas activas 9. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 13. 47b0ecc8: 21.413 - 76.466

- Rival ganador: agustinnunez. Diferencia final propia: -55.053.
- Estado: turno propio 190, remaining_moves=21; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_47b0ecc8-c5d5-11f1-96f5-a2aacf8fcf85.log:570>).
- Movimiento elegido: right. Alternativa: left.
- Motivo registrado: deep_control. Componentes: move_search.py (evaluacion/seguridad y candidatos), snake_brain.py (override/commit).
- Evidencia: search -1183536 vs -1179686; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 3.850, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 9. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 14. 4837c1ee: 25.382 - 50.125

- Rival ganador: santinovitale. Diferencia final propia: -24.743.
- Estado: turno propio 175, remaining_moves=52; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_4837c1ee-c5d5-11f1-96f5-a2aacf8fcf85.log:525>).
- Movimiento elegido: right. Alternativa: up.
- Motivo registrado: deep_control. Componentes: move_search.py (evaluacion/seguridad y candidatos), snake_brain.py (override/commit).
- Evidencia: search -626264 vs -609444; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 16.820, misma clase SAFE y no forced_loss; profundidad 5, partidas activas 12. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 15. 5580bbd6: 19.729 - 63.674

- Rival ganador: Slowpoke. Diferencia final propia: -43.945.
- Estado: turno propio 192, remaining_moves=18; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_5580bbd6-c5d4-11f1-96f5-a2aacf8fcf85.log:576>).
- Movimiento elegido: down. Alternativa: left.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: X 14 pasos / 9 turnos; X alternativo 5.
- Clasificacion: 1. Inconsistencia del horizonte de planificacion; 2. problema repetido de objetivo inalcanzable.
- Limite de la conclusion: Objetivo (7,15), alternativa (8,3). La alternativa es alcanzable en el horizonte observado; no se demostro que ganara la partida.

### 16. 55c1020e: 12.731 - 58.977

- Rival ganador: santinovitale. Diferencia final propia: -46.246.
- Estado: turno propio 158, remaining_moves=85; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_55c1020e-c5d4-11f1-96f5-a2aacf8fcf85.log:474>).
- Movimiento elegido: down. Alternativa: right.
- Motivo registrado: fallback_rival_pressure. Componentes: move_search.py (evaluacion/seguridad y candidatos), snake_brain.py (override/commit).
- Evidencia: search -658326 vs -647788; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 10.538, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 42. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 17. 55cffdf4: 28.526 - 56.074

- Rival ganador: agustinnunez. Diferencia final propia: -27.548.
- Estado: turno propio 114, remaining_moves=174; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_55cffdf4-c5d4-11f1-96f5-a2aacf8fcf85.log:342>).
- Movimiento elegido: left. Alternativa: up.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search -378560 vs -377280; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 1.280, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 59. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 18. 565bdfa4: 13.827 - 59.523

- Rival ganador: Porygon2. Diferencia final propia: -45.696.
- Estado: turno propio 155, remaining_moves=92; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_565bdfa4-c5d4-11f1-96f5-a2aacf8fcf85.log:465>).
- Movimiento elegido: up. Alternativa: left.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search -750776 vs -728098; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 22.678, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 42. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 19. 65abe450: 38.827 - 41.077

- Rival ganador: santinovitale. Diferencia final propia: -2.250.
- Estado: turno propio 200, remaining_moves=2; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_65abe450-c5d3-11f1-96f5-a2aacf8fcf85.log:600>).
- Movimiento elegido: up. Alternativa: no demostrada.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: sin alternativa superior confirmada.
- Clasificacion: 6. Evidencia insuficiente.
- Limite de la conclusion: Se informa el ultimo estado elegido como referencia del final. No se demostro una alternativa mejor ni se atribuye la derrota a este movimiento.

### 20. 65d33bea: -3.000 - 42.328

- Rival ganador: Slowpoke. Diferencia final propia: -45.328.
- Estado: turno propio 97, remaining_moves=207; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_65d33bea-c5d3-11f1-96f5-a2aacf8fcf85.log:291>).
- Movimiento elegido: up. Alternativa: sin salida sin choque.
- Motivo registrado: safe_direction_repair. Componentes: snake_brain.py (reparacion del movimiento), transicion v7 del estado.
- Evidencia: 15880 -> 0; legal=[].
- Clasificacion: 5. Choque dificil de evitar en este estado; 6. evidencia insuficiente sobre la ruta anterior.
- Limite de la conclusion: No habia movimiento seguro sin choque en este instante. No se culpa al fallback final ni se afirma que el encierro anterior fuera inevitable. La transicion de choque coincide con v7.

### 21. 6e908614: 28.825 - 64.022

- Rival ganador: Porygon2. Diferencia final propia: -35.197.
- Estado: turno propio 156, remaining_moves=90; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_6e908614-c5d5-11f1-96f5-a2aacf8fcf85.log:468>).
- Movimiento elegido: right. Alternativa: left.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search -275118 vs -242350; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 32.768, misma clase SAFE y no forced_loss; profundidad 5, partidas activas 15. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 22. 6f027328: 17.709 - 120.960

- Rival ganador: Slowpoke. Diferencia final propia: -103.251.
- Estado: turno propio 132, remaining_moves=138; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_6f027328-c5d5-11f1-96f5-a2aacf8fcf85.log:396>).
- Movimiento elegido: down. Alternativa: sin salida sin choque.
- Motivo registrado: safe_direction_repair. Componentes: snake_brain.py (reparacion del movimiento), transicion v7 del estado.
- Evidencia: 15311 -> 0; legal=[].
- Clasificacion: 5. Choque dificil de evitar en este estado; 6. evidencia insuficiente sobre la ruta anterior.
- Limite de la conclusion: No habia movimiento seguro sin choque en este instante. No se culpa al fallback final ni se afirma que el encierro anterior fuera inevitable. La transicion de choque coincide con v7.

### 23. 6f67d466: 49.420 - 62.474

- Rival ganador: agustinnunez. Diferencia final propia: -13.054.
- Estado: turno propio 128, remaining_moves=145; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_6f67d466-c5d5-11f1-96f5-a2aacf8fcf85.log:384>).
- Movimiento elegido: up. Alternativa: down.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search -397552 vs -394872; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 2.680, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 21. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 24. 7f2b6ab2: 30.228 - 42.672

- Rival ganador: Porygon2. Diferencia final propia: -12.444.
- Estado: turno propio 156, remaining_moves=90; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_7f2b6ab2-c5d4-11f1-96f5-a2aacf8fcf85.log:468>).
- Movimiento elegido: right. Alternativa: up.
- Motivo registrado: survival_control. Componentes: move_search.py (evaluacion/seguridad y candidatos), snake_brain.py (override/commit).
- Evidencia: search -208774 vs -205624; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 3.150, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 38. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 25. 7f466bb4: 22.531 - 66.822

- Rival ganador: Slowpoke. Diferencia final propia: -44.291.
- Estado: turno propio 164, remaining_moves=74; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_7f466bb4-c5d4-11f1-96f5-a2aacf8fcf85.log:492>).
- Movimiento elegido: up. Alternativa: right.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search -755722 vs -741384; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 14.338, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 37. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 26. 8cdff6d8: 40.577 - 50.325

- Rival ganador: Slowpoke. Diferencia final propia: -9.748.
- Estado: turno propio 104, remaining_moves=193; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_8cdff6d8-c5d3-11f1-96f5-a2aacf8fcf85.log:312>).
- Movimiento elegido: up. Alternativa: right.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search -203810 vs -202390; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 1.420, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 25. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 27. 8d0be266: 38.373 - 42.628

- Rival ganador: agustinnunez. Diferencia final propia: -4.255.
- Estado: turno propio 124, remaining_moves=154; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_8d0be266-c5d3-11f1-96f5-a2aacf8fcf85.log:372>).
- Movimiento elegido: up. Alternativa: left.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search 343716 vs 384294; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 40.578, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 28. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 28. 8d25279e: 15.086 - 39.328

- Rival ganador: santinovitale. Diferencia final propia: -24.242.
- Estado: turno propio 196, remaining_moves=9; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_8d25279e-c5d3-11f1-96f5-a2aacf8fcf85.log:588>).
- Movimiento elegido: up. Alternativa: up.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: X 8 pasos / 5 turnos; X alternativo 3.
- Clasificacion: 1. Inconsistencia del horizonte de planificacion; 2. problema repetido de objetivo inalcanzable.
- Limite de la conclusion: Objetivo (0,5), alternativa (2,8). Ambos objetivos empiezan por la misma direccion: cambia el destino, no necesariamente el primer movimiento. La alternativa es alcanzable en el horizonte observado; no se demostro que ganara la partida.

### 29. 8d3542fa: 15.661 - 58.872

- Rival ganador: Porygon2. Diferencia final propia: -43.211.
- Estado: turno propio 132, remaining_moves=138; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_8d3542fa-c5d3-11f1-96f5-a2aacf8fcf85.log:396>).
- Movimiento elegido: down. Alternativa: sin salida sin choque.
- Motivo registrado: safe_direction_repair. Componentes: snake_brain.py (reparacion del movimiento), transicion v7 del estado.
- Evidencia: 18263 -> 0; legal=[].
- Clasificacion: 5. Choque dificil de evitar en este estado; 6. evidencia insuficiente sobre la ruta anterior.
- Limite de la conclusion: No habia movimiento seguro sin choque en este instante. No se culpa al fallback final ni se afirma que el encierro anterior fuera inevitable. La transicion de choque coincide con v7.

### 30. a8198fb2: 32.323 - 68.675

- Rival ganador: Slowpoke. Diferencia final propia: -36.352.
- Estado: turno propio 191, remaining_moves=20; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_a8198fb2-c5d4-11f1-96f5-a2aacf8fcf85.log:573>).
- Movimiento elegido: right. Alternativa: down.
- Motivo registrado: survival_control. Componentes: move_search.py (evaluacion/seguridad y candidatos), snake_brain.py (override/commit).
- Evidencia: search -945170 vs -943300; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 1.870, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 25. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 31. a8601432: 33.479 - 52.324

- Rival ganador: Porygon2. Diferencia final propia: -18.845.
- Estado: turno propio 145, remaining_moves=111; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_a8601432-c5d4-11f1-96f5-a2aacf8fcf85.log:435>).
- Movimiento elegido: down. Alternativa: up.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search -276620 vs -276300; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 320, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 37. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 32. a88ee6ae: 10.579 - 26.531

- Rival ganador: agustinnunez. Diferencia final propia: -15.952.
- Estado: turno propio 200, remaining_moves=1; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_a88ee6ae-c5d4-11f1-96f5-a2aacf8fcf85.log:600>).
- Movimiento elegido: down. Alternativa: no demostrada.
- Motivo registrado: survival_control. Componentes: move_search.py (evaluacion/seguridad y candidatos), snake_brain.py (override/commit).
- Evidencia: sin alternativa superior confirmada.
- Clasificacion: 6. Evidencia insuficiente.
- Limite de la conclusion: Se informa el ultimo estado elegido como referencia del final. No se demostro una alternativa mejor ni se atribuye la derrota a este movimiento.

### 33. a8971630: 11.222 - 14.036

- Rival ganador: gabrielflores. Diferencia final propia: -2.814.
- Estado: turno propio 174, remaining_moves=54; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_a8971630-c5d4-11f1-96f5-a2aacf8fcf85.log:522>).
- Movimiento elegido: up. Alternativa: sin salida sin choque.
- Motivo registrado: safe_direction_repair. Componentes: snake_brain.py (reparacion del movimiento), transicion v7 del estado.
- Evidencia: 50794 -> 0; legal=[].
- Clasificacion: 5. Choque dificil de evitar en este estado; 6. evidencia insuficiente sobre la ruta anterior.
- Limite de la conclusion: No habia movimiento seguro sin choque en este instante. No se culpa al fallback final ni se afirma que el encierro anterior fuera inevitable. La transicion de choque coincide con v7.

### 34. a8bd5d0e: 30.526 - 56.473

- Rival ganador: santinovitale. Diferencia final propia: -25.947.
- Estado: turno propio 134, remaining_moves=133; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_a8bd5d0e-c5d4-11f1-96f5-a2aacf8fcf85.log:402>).
- Movimiento elegido: up. Alternativa: right.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search -622020 vs -620770; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 1.250, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 38. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 35. b44f29a0: 31.926 - 42.276

- Rival ganador: agustinnunez. Diferencia final propia: -10.350.
- Estado: turno propio 180, remaining_moves=42; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_b44f29a0-c5d3-11f1-96f5-a2aacf8fcf85.log:540>).
- Movimiento elegido: left. Alternativa: up.
- Motivo registrado: deep_control. Componentes: move_search.py (evaluacion/seguridad y candidatos), snake_brain.py (override/commit).
- Evidencia: search -440896 vs -435736; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 5.160, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 44. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 36. b459fac4: 59.620 - 87.072

- Rival ganador: Slowpoke. Diferencia final propia: -27.452.
- Estado: turno propio 134, remaining_moves=134; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_b459fac4-c5d3-11f1-96f5-a2aacf8fcf85.log:402>).
- Movimiento elegido: down. Alternativa: left.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search -620536 vs -619496; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 1.040, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 37. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 37. b4a851a6: 9 - 53.875

- Rival ganador: santinovitale. Diferencia final propia: -53.866.
- Estado: turno propio 191, remaining_moves=19; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_b4a851a6-c5d3-11f1-96f5-a2aacf8fcf85.log:573>).
- Movimiento elegido: up. Alternativa: sin salida sin choque.
- Motivo registrado: safe_direction_repair. Componentes: snake_brain.py (reparacion del movimiento), transicion v7 del estado.
- Evidencia: 38415 -> 0; legal=[].
- Clasificacion: 5. Choque dificil de evitar en este estado; 6. evidencia insuficiente sobre la ruta anterior.
- Limite de la conclusion: No habia movimiento seguro sin choque en este instante. No se culpa al fallback final ni se afirma que el encierro anterior fuera inevitable. La transicion de choque coincide con v7.

### 38. b505007c: 42.822 - 49.126

- Rival ganador: Porygon2. Diferencia final propia: -6.304.
- Estado: turno propio 200, remaining_moves=2; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_b505007c-c5d3-11f1-96f5-a2aacf8fcf85.log:600>).
- Movimiento elegido: right. Alternativa: no demostrada.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: sin alternativa superior confirmada.
- Clasificacion: 6. Evidencia insuficiente.
- Limite de la conclusion: Se informa el ultimo estado elegido como referencia del final. No se demostro una alternativa mejor ni se atribuye la derrota a este movimiento.

### 39. d1cacc36: -3.000 - 51.072

- Rival ganador: santinovitale. Diferencia final propia: -54.072.
- Estado: turno propio 143, remaining_moves=115; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_d1cacc36-c5d4-11f1-96f5-a2aacf8fcf85.log:429>).
- Movimiento elegido: up. Alternativa: sin salida sin choque.
- Motivo registrado: safe_direction_repair. Componentes: snake_brain.py (reparacion del movimiento), transicion v7 del estado.
- Evidencia: 29822 -> 0; legal=[].
- Clasificacion: 5. Choque dificil de evitar en este estado; 6. evidencia insuficiente sobre la ruta anterior.
- Limite de la conclusion: No habia movimiento seguro sin choque en este instante. No se culpa al fallback final ni se afirma que el encierro anterior fuera inevitable. La transicion de choque coincide con v7.

### 40. d20b37a8: 36.569 - 91.972

- Rival ganador: Porygon2. Diferencia final propia: -55.403.
- Estado: turno propio 94, remaining_moves=213; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_d20b37a8-c5d4-11f1-96f5-a2aacf8fcf85.log:282>).
- Movimiento elegido: up. Alternativa: right.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search -540466 vs -520288; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 20.178, misma clase SAFE y no forced_loss; profundidad 5, partidas activas 42. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 41. d2eae89e: 14 - 65.413

- Rival ganador: Slowpoke. Diferencia final propia: -65.399.
- Estado: turno propio 186, remaining_moves=29; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_d2eae89e-c5d4-11f1-96f5-a2aacf8fcf85.log:558>).
- Movimiento elegido: down. Alternativa: sin salida sin choque.
- Motivo registrado: safe_direction_repair. Componentes: snake_brain.py (reparacion del movimiento), transicion v7 del estado.
- Evidencia: 37207 -> 0; legal=[].
- Clasificacion: 5. Choque dificil de evitar en este estado; 6. evidencia insuficiente sobre la ruta anterior.
- Limite de la conclusion: No habia movimiento seguro sin choque en este instante. No se culpa al fallback final ni se afirma que el encierro anterior fuera inevitable. La transicion de choque coincide con v7.

### 42. dbc0e370: 32.022 - 54.769

- Rival ganador: santinovitale. Diferencia final propia: -22.747.
- Estado: turno propio 61, remaining_moves=279; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_dbc0e370-c5d3-11f1-96f5-a2aacf8fcf85.log:183>).
- Movimiento elegido: down. Alternativa: right.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search -324886 vs -302288; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 22.598, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 32. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 43. dbf99c38: 14.436 - 66.411

- Rival ganador: agustinnunez. Diferencia final propia: -51.975.
- Estado: turno propio 160, remaining_moves=81; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_dbf99c38-c5d3-11f1-96f5-a2aacf8fcf85.log:480>).
- Movimiento elegido: down. Alternativa: sin salida sin choque.
- Motivo registrado: safe_direction_repair. Componentes: snake_brain.py (reparacion del movimiento), transicion v7 del estado.
- Evidencia: 38585 -> 0; legal=[].
- Clasificacion: 5. Choque dificil de evitar en este estado; 6. evidencia insuficiente sobre la ruta anterior.
- Limite de la conclusion: No habia movimiento seguro sin choque en este instante. No se culpa al fallback final ni se afirma que el encierro anterior fuera inevitable. La transicion de choque coincide con v7.

### 44. dc309260: 46.620 - 121.513

- Rival ganador: Slowpoke. Diferencia final propia: -74.893.
- Estado: turno propio 125, remaining_moves=151; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_dc309260-c5d3-11f1-96f5-a2aacf8fcf85.log:375>).
- Movimiento elegido: left. Alternativa: right.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search -613244 vs -612444; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 800, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 38. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

### 45. f9a5010e: 1 - 86.964

- Rival ganador: Slowpoke. Diferencia final propia: -86.963.
- Estado: turno propio 199, remaining_moves=3; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_f9a5010e-c5d4-11f1-96f5-a2aacf8fcf85.log:597>).
- Movimiento elegido: down. Alternativa: sin salida sin choque.
- Motivo registrado: safe_direction_repair. Componentes: snake_brain.py (reparacion del movimiento), transicion v7 del estado.
- Evidencia: 43567 -> 0; legal=[].
- Clasificacion: 5. Choque dificil de evitar en este estado; 6. evidencia insuficiente sobre la ruta anterior.
- Limite de la conclusion: No habia movimiento seguro sin choque en este instante. No se culpa al fallback final ni se afirma que el encierro anterior fuera inevitable. La transicion de choque coincide con v7.

### 46. f9c9fc5c: 2 - 43.724

- Rival ganador: agustinnunez. Diferencia final propia: -43.722.
- Estado: turno propio 198, remaining_moves=6; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_f9c9fc5c-c5d4-11f1-96f5-a2aacf8fcf85.log:594>).
- Movimiento elegido: up. Alternativa: sin salida sin choque.
- Motivo registrado: safe_direction_repair. Componentes: snake_brain.py (reparacion del movimiento), transicion v7 del estado.
- Evidencia: 40862 -> 0; legal=[].
- Clasificacion: 5. Choque dificil de evitar en este estado; 6. evidencia insuficiente sobre la ruta anterior.
- Limite de la conclusion: No habia movimiento seguro sin choque en este instante. No se culpa al fallback final ni se afirma que el encierro anterior fuera inevitable. La transicion de choque coincide con v7.

### 47. fa2f4b0c: 53.574 - 102.211

- Rival ganador: santinovitale. Diferencia final propia: -48.637.
- Estado: turno propio 94, remaining_moves=213; [log y diagnostico](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_fa2f4b0c-c5d4-11f1-96f5-a2aacf8fcf85.log:282>).
- Movimiento elegido: up. Alternativa: right.
- Motivo registrado: food_plan. Componentes: food_planner.py (objetivo), snake_brain.py (coordinacion/commit).
- Evidencia: search -620046 vs -608508; ajuste=0.
- Clasificacion: 4. Problema de integracion de busqueda: diferencias saturadas, patron repetido.
- Limite de la conclusion: La alternativa tiene mayor utilidad profunda por 11.538, misma clase SAFE y no forced_loss; profundidad 4, partidas activas 39. No es una victoria contrafactual ni demuestra que esta decision causara la derrota.

## Manifiesto de la tanda fija

Los siguientes 86 archivos forman el universo analizado. Los nombres incluyen el game_id completo.

- [game_04a7f53a-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_04a7f53a-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_04eccdea-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_04eccdea-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_04fa4d58-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_04fa4d58-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_0500270a-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_0500270a-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_05107bfa-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_05107bfa-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_055a2cc8-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_055a2cc8-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_1f918f86-c5d5-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_1f918f86-c5d5-11f1-96f5-a2aacf8fcf85.log>)
- [game_2027a5c0-c5d5-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_2027a5c0-c5d5-11f1-96f5-a2aacf8fcf85.log>)
- [game_20a8f86e-c5d5-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_20a8f86e-c5d5-11f1-96f5-a2aacf8fcf85.log>)
- [game_20b7ec16-c5d5-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_20b7ec16-c5d5-11f1-96f5-a2aacf8fcf85.log>)
- [game_20c47c4c-c5d5-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_20c47c4c-c5d5-11f1-96f5-a2aacf8fcf85.log>)
- [game_20dbb92a-c5d5-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_20dbb92a-c5d5-11f1-96f5-a2aacf8fcf85.log>)
- [game_2cc04982-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_2cc04982-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_2cd0a804-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_2cd0a804-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_2ce3c402-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_2ce3c402-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_2d2994e6-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_2d2994e6-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_2d34f854-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_2d34f854-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_2d4deddc-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_2d4deddc-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_3f5e25c4-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_3f5e25c4-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_3f697122-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_3f697122-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_3f6e66d2-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_3f6e66d2-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_3f728c4e-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_3f728c4e-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_3f7633e4-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_3f7633e4-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_3f7db358-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_3f7db358-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_474a1da4-c5d5-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_474a1da4-c5d5-11f1-96f5-a2aacf8fcf85.log>)
- [game_47b0ecc8-c5d5-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_47b0ecc8-c5d5-11f1-96f5-a2aacf8fcf85.log>)
- [game_47b4f71e-c5d5-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_47b4f71e-c5d5-11f1-96f5-a2aacf8fcf85.log>)
- [game_483477a0-c5d5-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_483477a0-c5d5-11f1-96f5-a2aacf8fcf85.log>)
- [game_4837c1ee-c5d5-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_4837c1ee-c5d5-11f1-96f5-a2aacf8fcf85.log>)
- [game_55763db4-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_55763db4-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_5580bbd6-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_5580bbd6-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_55c1020e-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_55c1020e-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_55cffdf4-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_55cffdf4-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_5653a5dc-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_5653a5dc-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_565bdfa4-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_565bdfa4-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_656e234a-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_656e234a-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_659ecc16-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_659ecc16-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_65a2d162-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_65a2d162-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_65abe450-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_65abe450-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_65d33bea-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_65d33bea-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_6606a804-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_6606a804-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_6e908614-c5d5-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_6e908614-c5d5-11f1-96f5-a2aacf8fcf85.log>)
- [game_6efeefc8-c5d5-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_6efeefc8-c5d5-11f1-96f5-a2aacf8fcf85.log>)
- [game_6f027328-c5d5-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_6f027328-c5d5-11f1-96f5-a2aacf8fcf85.log>)
- [game_6f67d466-c5d5-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_6f67d466-c5d5-11f1-96f5-a2aacf8fcf85.log>)
- [game_7da424b8-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_7da424b8-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_7ebb74e6-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_7ebb74e6-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_7f2b6ab2-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_7f2b6ab2-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_7f466bb4-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_7f466bb4-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_7f7e4e8a-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_7f7e4e8a-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_8cdff6d8-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_8cdff6d8-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_8cf08c3c-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_8cf08c3c-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_8cfb2458-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_8cfb2458-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_8d0be266-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_8d0be266-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_8d25279e-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_8d25279e-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_8d3542fa-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_8d3542fa-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_a8198fb2-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_a8198fb2-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_a8601432-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_a8601432-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_a882de40-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_a882de40-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_a88ee6ae-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_a88ee6ae-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_a8971630-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_a8971630-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_a8bd5d0e-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_a8bd5d0e-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_b44f29a0-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_b44f29a0-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_b459fac4-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_b459fac4-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_b4a851a6-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_b4a851a6-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_b4fb14a4-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_b4fb14a4-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_b505007c-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_b505007c-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_b51b002a-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_b51b002a-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_d1cacc36-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_d1cacc36-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_d20b37a8-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_d20b37a8-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_d23b7e5e-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_d23b7e5e-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_d24f2774-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_d24f2774-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_d2e6e4d8-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_d2e6e4d8-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_d2eae89e-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_d2eae89e-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_dbc0e370-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_dbc0e370-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_dbcec6a2-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_dbcec6a2-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_dbf99c38-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_dbf99c38-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_dc309260-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_dc309260-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_dc35da90-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_dc35da90-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_dcbb9e14-c5d3-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_dcbb9e14-c5d3-11f1-96f5-a2aacf8fcf85.log>)
- [game_f9a5010e-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_f9a5010e-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_f9c9fc5c-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_f9c9fc5c-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_fa1d6018-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_fa1d6018-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_fa2f4b0c-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_fa2f4b0c-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_fa32ce6c-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_fa32ce6c-c5d4-11f1-96f5-a2aacf8fcf85.log>)
- [game_faf8a8d0-c5d4-11f1-96f5-a2aacf8fcf85.log](<C:/Users/ariel/OneDrive/Desktop/Computacion Bot/Codechallenge/games/game_faf8a8d0-c5d4-11f1-96f5-a2aacf8fcf85.log>)

## Integridad de la entrega

Este informe es el unico archivo creado por esta entrega y esta fuera del repositorio. No se editaron logs, fuentes, tests, pesos ni configuracion. No se iniciaron partidas, benchmarks u optimizaciones. Los cambios locales previos se conservaron sin intervenirlos.

